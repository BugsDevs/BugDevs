const express = require('express');
const mysql = require('mysql2');
const path = require('path');
const app = express();

// Configuração do middleware
app.use(express.static(path.join(__dirname))); // Serve arquivos estáticos
app.use(express.json()); // Para parsear JSON no corpo das requisições

// Configuração do banco de dados MySQL
const db = mysql.createConnection({
    host: 'localhost',
    user: 'admin', // Substitua pelo seu usuário do MySQL
    password: '123', // Substitua pela sua senha do MySQL
    database: 'devsimples'
});

db.connect(err => {
    if (err) {
        console.error('Erro ao conectar ao MySQL:', err);
        return;
    }
    console.log('Conectado ao MySQL!');
});

// Rota explícita para a página inicial
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Rota para listar produtos
app.get('/api/produtos', (req, res) => {
    db.query('SELECT * FROM produtos', (err, results) => {
        if (err) {
            res.status(500).json({ error: 'Erro ao buscar produtos' });
            return;
        }
        res.json(results);
    });
});

// Rota para salvar pedidos
app.post('/api/pedidos', (req, res) => {
    const { nome, email, itens } = req.body;
    const total = itens.reduce((sum, item) => sum + item.preco, 0);

    db.query(
        'INSERT INTO pedidos (nome, email, total) VALUES (?, ?, ?)',
        [nome, email, total],
        (err, result) => {
            if (err) {
                res.status(500).json({ error: 'Erro ao salvar pedido' });
                return;
            }
            res.json({ message: 'Pedido enviado com sucesso!' });
        }
    );
});

// Iniciar o servidor
app.listen(3000, () => {
    console.log('Servidor rodando em http://localhost:3000');
});