-- Criar o banco de dados
CREATE DATABASE devsimples;
USE devsimples;

-- Criar tabela de produtos
CREATE TABLE produtos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    descricao TEXT NOT NULL,
    preco DECIMAL(10,2) NOT NULL
);

-- Inserir produtos de exemplo
INSERT INTO produtos (nome, descricao, preco) VALUES
('Smoothie de Morango', 'Smoothie refrescante de morango com iogurte.', 10.00),
('Smoothie de Banana', 'Smoothie cremoso de banana com leite.', 8.00),
('Smoothie de Manga', 'Smoothie tropical de manga com suco de laranja.', 12.00),
('Smoothie de Frutas Vermelhas', 'Mix de frutas vermelhas com toque de limão.', 11.00);

-- Criar tabela de pedidos
CREATE TABLE pedidos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    total DECIMAL(10,2) NOT NULL,
    data_pedido TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
create user 'admin'@'localhost' identified by '123';
grant all privileges on devsimples.* to 'admin'@'localhost';
flush privileges;